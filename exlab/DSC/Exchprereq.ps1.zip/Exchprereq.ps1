﻿#Exchprereq.ps1


Configuration Exchprereq

{

Param (		
	[Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [String]$VMName,

        [Parameter(Mandatory)]
        [PSCredential]$Admincreds,

        [Int]$RetryCount=10,
        [Int]$RetryIntervalSec=30 )

#DSC starts here

#$User = "$DomainName\$($Admincreds.UserName)"
[System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ($Admincreds.UserName, $Admincreds.Password)
#[PSCredential]$DomainCreds = New-Object PSCredential ("$DomainName/$Admincreds.UserName, $Admincreds.Password)

Import-DscResource -module xPendingReboot
Import-DscResource -module xPSDesiredStateConfiguration
Import-DscResource -module PSDesiredStateConfiguration
Import-DscResource -module xExchange

$Ucma = "https://download.microsoft.com/download/2/C/4/2C47A5C1-A1F3-4843-B9FE-84C0032C61EC/UcmaRuntimeSetup.exe"
$UcmaDesPath = "C:\Packages\UcmaRuntimeSetup.exe"
$Exsetup = "https://download.microsoft.com/download/3/9/B/39B25E37-2265-4FBC-AF87-7CA6CA089615/Exchange2013-x64-cu20.exe"
$ExsetupDesPath = "C:\Packages\Exchange2013-x64-cu20.exe"
$NetFram = "https://download.microsoft.com/download/F/9/4/F942F07D-F26F-4F30-B4E3-EBD54FABA377/NDP462-KB3151800-x86-x64-AllOS-ENU.exe"
$NetFramDesPath = "C:\Packages\NDP462-KB3151800-x86-x64-AllOS-ENU.exe"
$Setupfolder = "C:\ExSetup"
$netbios=$DomainName.split(“.”)[0]



# Exchange 2013 rerequisit features

    Node localhost
  {
	LocalConfigurationManager 
        {
       		ActionAfterReboot = 'ContinueConfiguration'    
		ConfigurationMode = 'ApplyOnly'
          	RebootNodeIfNeeded = $true
	}
	xPendingReboot BeforePrereqsInstall
     	 { 
            Name = "BeforePrereqsInstall"
     	 }
	
        WindowsFeature ASHTTP
        {
            Ensure = 'Present'
            Name = 'AS-HTTP-Activation'
        }
        WindowsFeature DesktopExp
        {
            Ensure = 'Present'
            Name = 'Desktop-Experience'
        }
         WindowsFeature NetFW45
        {
            Ensure = 'Present'
            Name = 'NET-Framework-45-Features'
        }
           WindowsFeature RPCProxy
        {
            Ensure = 'Present'
            Name = 'RPC-over-HTTP-proxy'
        }
            WindowsFeature RSATClus
        {
            Ensure = 'Present'
            Name = 'RSAT-Clustering'
        }
            WindowsFeature RSATClusCmd
        {
            Ensure = 'Present'
            Name = 'RSAT-Clustering-CmdInterface'
        }
            WindowsFeature RSATClusMgmt
        {
            Ensure = 'Present'
            Name = 'RSAT-Clustering-Mgmt'
        }
           WindowsFeature RSATClusPS
        {
            Ensure = 'Present'
            Name = 'RSAT-Clustering-PowerShell'
        }
           WindowsFeature WebConsole
        {
            Ensure = 'Present'
            Name = 'Web-Mgmt-Console'
        }
            WindowsFeature WAS
        {
            Ensure = 'Present'
            Name = 'WAS-Process-Model'
        }
            WindowsFeature WebAsp
        {
            Ensure = 'Present'
            Name = 'Web-Asp-Net45'
        }
           WindowsFeature WBA
        {
            Ensure = 'Present'
            Name = 'Web-Basic-Auth'
        }
           WindowsFeature WCA
        {
            Ensure = 'Present'
            Name = 'Web-Client-Auth'
        }
          WindowsFeature WDA
        {
            Ensure = 'Present'
            Name = 'Web-Digest-Auth'
        }
          WindowsFeature WDB
        {
            Ensure = 'Present'
            Name = 'Web-Dir-Browsing'
        }
           WindowsFeature WDC
        {
            Ensure = 'Present'
            Name = 'Web-Dyn-Compression'
        }
           WindowsFeature WebHttp
        {
            Ensure = 'Present'
            Name = 'Web-Http-Errors'
        }
           WindowsFeature WebHttpLog
        {
            Ensure = 'Present'
            Name = 'Web-Http-Logging'
        }
           WindowsFeature WebHttpRed
        {
            Ensure = 'Present'
            Name = 'Web-Http-Redirect'
        }
          WindowsFeature WebHttpTrac
        {
            Ensure = 'Present'
            Name = 'Web-Http-Tracing'
        }
          WindowsFeature WebISAPI
        {
            Ensure = 'Present'
            Name = 'Web-ISAPI-Ext'
        }
          WindowsFeature WebISAPIFilt
        {
            Ensure = 'Present'
            Name = 'Web-ISAPI-Filter'
        }
            WindowsFeature WebLgcyMgmt
        {
            Ensure = 'Present'
            Name = 'Web-Lgcy-Mgmt-Console'
        }
            WindowsFeature WebMetaDB
        {
            Ensure = 'Present'
            Name = 'Web-Metabase'
        }
            WindowsFeature WebMgmtSvc
        {
            Ensure = 'Present'
            Name = 'Web-Mgmt-Service'
        }
           WindowsFeature WebNet45
        {
            Ensure = 'Present'
            Name = 'Web-Net-Ext45'
        }
            WindowsFeature WebReq
        {
            Ensure = 'Present'
            Name = 'Web-Request-Monitor'
        }
             WindowsFeature WebSrv
        {
            Ensure = 'Present'
            Name = 'Web-Server'
        }
              WindowsFeature WebStat
        {
            Ensure = 'Present'
            Name = 'Web-Stat-Compression'
        }
               WindowsFeature WebStatCont
        {
            Ensure = 'Present'
            Name = 'Web-Static-Content'
        }
               WindowsFeature WebWindAuth
        {
            Ensure = 'Present'
            Name = 'Web-Windows-Auth'
        }
              WindowsFeature WebWMI
        {
            Ensure = 'Present'
            Name = 'Web-WMI'
        }
              WindowsFeature WebIF
        {
            Ensure = 'Present'
            Name = 'Windows-Identity-Foundation'
        }
              WindowsFeature RSATADDS
        {
            Ensure = 'Present'
            Name = 'RSAT-ADDS'
        }

	xRemoteFile DownloadUCMA
        {
            DestinationPath = $UcmaDesPath
            Uri = $UCMA
	    
        }
	xRemoteFile DownloadExsetup
        {
            DestinationPath = $ExsetupDesPath
            Uri = $Exsetup
	    
        } 
	xRemoteFile DownloadNetfram
        {
            DestinationPath = $NetFramDesPath
            Uri = $NetFram
	    
        } 	
	xPendingReboot BeforeUCMAInstall
        {
            Name      = "BeforeUCMAInstall"
 	}

	
# Install Microsoft Unified Communications Managed API 
	Package UCMA
        {
            Ensure= 'Present'
            Name = 'Microsoft Unified Communications Managed API 4.0, Core
                    Runtime 64-bit'
            Path= "C:\Packages\UcmaRuntimeSetup.exe"
            ProductID= 'ED98ABF5-B6BF-47ED-92AB-1CDCAB964447'
            Arguments= '/q'
	    DependsOn = '[xRemoteFile]DownloadUCMA'
          }

#Extracting Exchange setup
	File ExFolder 
	{
		Ensure = "Present"    
		Type = 'Directory'
		DestinationPath = $Setupfolder
         }

	Script ExtractExfile
         {
           	GetScript = 
	{
		$content  = Get-ChildItem C:\ExSetup
	}
		TestScript =
	{
	if  ($content -eq $null)
	{
		Write-Verbose "File Not Found"
		Return $false
	}
	else 
	{
		Write-Verbose "File Found"
		Return $True	
	}
	}
		SetScript = 
	{
		Write-Verbose "Extracting Setup"
		C:\Packages\Exchange2013-x64-cu20.exe /x:c:\ExSetup /q
	}
        }
 
#Checks if a reboot is needed before installing Exchange

        xPendingReboot BeforeExchangeInstall
        {
            Name      = "BeforeExchangeInstall"
            DependsOn  = '[Package]UCMA'
        }

#Does the Exchange install. Verify directory with exchange binaries
        xExchInstall InstallExchange
        {
            Path       = "C:\ExSetup\Setup.exe"
            Arguments  = "/mode:Install /role:Mailbox /OrganizationName:""$netbios"" /Iacceptexchangeserverlicenseterms"
            Credential = $DomainCreds
            DependsOn  = '[File]ExFolder'
        }
 
#Sees if a reboot is required after installing Exchange
        xPendingReboot AfterExchangeInstall
        {
            Name      = "AfterExchangeInstall"
            DependsOn = '[xExchInstall]InstallExchange'
        }

     }
}


 



