﻿#Domainjoin.ps1
#

Configuration Domainjoin

{


Param (		
	[string[]]$NodeName="localhost",

	[Parameter(Mandatory)] 
        [string]$VMName, 
 
	[Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [PSCredential]$Admincreds,
		    
	[Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30 )

        
Import-DscResource -ModuleName xComputerManagement, xPendingReboot 
[PSCredential ]$DomainCreds = New-Object PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
 
#DSC starts here

Node $NodeName

    {
	xPendingReboot Reboot1
      { 
            Name = "BeforedomainJoin"
      }


    # Join domain
    xComputer JoinDomain
        {
	 Name	= $VMName
         DomainName = $DomainName
         Credential = $DomainCreds
           
        }
	xPendingReboot Reboot2
      { 
            Name = "AfterdomainJoin"
      }


    }

}



